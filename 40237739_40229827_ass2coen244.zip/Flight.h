// by Yazan - 40237739 & Parmeet - 40229827

#ifndef FLIGHT_H
#define FLIGHT_H
#include "Time.h"
#include "Date.h"
#include <string>
using namespace std;

class Flight
{
    string Flight_Identifier;
    string d_city;
    string a_city;
    int duration_of_Flight;

    Time* a_time;
    Time* d_time;
    Date* a_date;
    Date* d_date;

public:
    //constructors.
    Flight(string FI, string DC, string AC, int DoF, Time* At, Time* DT, Date* dD, Date* aD);
    Flight(const Flight& other);

    //setters.
    void set_Flight_Identifier(string FI);
    void set_DepartureCity(string DC);
    void set_Arrival_City(string Ac);
    void set_Duration(int Dur);
    void set_Arrival_T(Time* AT);
    void set_Departure_T(Time* DT);


    //getters.
    string get_Flight_Identifier() const;
    string get_DepartureCity() const;
    string get_Arrival_City() const;
    int get_Duration() const;
    Time* get_Arrival_Time() const;
    Time* get_Departure_Time() const;


    //destructor.
    ~Flight();



};

#endif

