// by Yazan - 40237739 & Parmeet - 40229827
#include "Airline.h"
#include "Flight.h"
#include "Time.h"
#include <string>
#include <iostream>
using namespace std;
//constructor
Airline::Airline(string telephone, string address, string name, int numFlights)
{
	this->telephone = telephone;
	this->address = address;
	this->name = name;
	this->numFlights = numFlights;
	flights = new Flight * [capacity];
}

//Destructors.

Airline::~Airline()
{
	for (int i = 0; i < numFlights; i++)
	{
		delete flights[i];
	}
	delete[] flights;
}

//setters
void Airline::set_telephone(string telephone)
{
	this->telephone = telephone;
}
void Airline::set_address(string address)
{
	this->address = address;
}
void Airline::set_name(string name)
{
	this->name = name;
}

void Airline::set_numFlights(int numFligjhts)
{
	this->numFlights = numFlights;
}


//getters
string Airline::get_telephone() const
{
	return telephone;
}
string Airline::get_address() const
{
	return address;
}
string Airline::get_name() const
{
	return name;
}

int Airline::get_numFlights() const
{
	return numFlights;
}

//Operations on the class.
void Airline::addFlights(Flight* flight)
{
	if (numFlights < capacity)
	{
		flights[numFlights] = flight;
		numFlights++;
	}
}

void Airline::listDepartingFlights(string DC)
{
	for (int i = 0; i < numFlights; i++)
	{
		if (flights[i]->get_DepartureCity() == DC)
		{
			if (i == 0)
				cout << "\nAll the flights departing from this given city are:- \n";

			cout << flights[i]->get_Flight_Identifier() << " ";
		}
	}
	cout << '\n';
}

void Airline::listArrivingFlights(string AC)
{
	for (int i = 0; i < numFlights; i++)
	{
		if (flights[i]->get_Arrival_City() == AC)
		{
			if (i == 0)
				cout << "\nAll the flights arriving in the given city are:- \n";
			cout << flights[i]->get_Arrival_City() << " ";
		}

	}
	cout << '\n';

}

void Airline::listarrivingandDepartingFlights(string AC, string DC)
{
	for (int i = 0; i < numFlights; i++)
	{
		if (flights[i]->get_Arrival_City() == AC)
		{
			if (i == 0)
				cout << "\nAll the flights arriving in the given city are:- \n";
			cout << flights[i]->get_Arrival_City() << " ";
		}
		cout << '\n';
	}

	for (int i = 0; i < numFlights; i++)
	{
		if (flights[i]->get_DepartureCity() == AC)
		{
			if (i == 0)
				cout << "\nAll the flights arriving in the given city are:- \n";
			cout << flights[i]->get_DepartureCity() << " ";
		}
		cout << '\n';
	}

}

void Airline::removeFlight(string identifier)
{
	for (int i = 0; i < numFlights; i++)
	{
		if (flights[i]->get_Flight_Identifier() == identifier)
		{
			delete flights[i];
			flights[i] = flights[numFlights - 1];
			numFlights--;
			cout << "\nFlight Identifier " << identifier << " removed successfully.\n";
		}
	}
}

void Airline::list_AllFlights()
{
	cout << "Details of all the flights:- ";
	for (int i = 0; i < numFlights; i++)
	{
		cout << flights[i]->get_Flight_Identifier() << " ";
	}
	cout << '\n';
}