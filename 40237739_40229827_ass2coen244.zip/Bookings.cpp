// by Yazan - 40237739 & Parmeet - 40229827
#include "Bookings.h"
#include "Time.h"
#include "Flight.h"
#include "Passenger.h"
#include "Airline.h"
#include <iostream>
using namespace std;

//constructor
Bookings::Bookings(int numPass = 0, int numFlights = 0)
{
	this->numPass = numPass;
	this->numFlights = numFlights;
	passengers = new Passenger * [capacity];
	flights = new Flight * [capacity];
}

//destructor
Bookings::~Bookings()
{

	for (int i = 0; i < capacity; i++)
	{
		delete passengers[i];
	}

	for (int i = 0; i < capacity; i++)
	{
		delete flights[i];
	}

	delete[] flights;
	delete[] passengers;
}

void Bookings::add_passengers(Passenger* p1)
{
	if (numPass < capacity)
	{
		passengers[numPass] = p1;
		numPass++;
	}

}
void Bookings::add_flights(Flight* f1)
{
	if (numFlights < capacity)
	{
		flights[numFlights] = f1;
		numFlights++;
	}
}

void Bookings::Information(string name, string flightID)
{
	for (int i = 0; i < capacity; i++)
	{
		if (passengers[i]->get_name() == name)
		{
			if (i == 0)
				cout << "\nAll the bookings for Mr/Mrs " << name << " is\n";
			cout << flights[i]->get_Flight_Identifier() << " " << flights[i]->get_DepartureCity() << " " << flights[i]->get_Arrival_City() << " " << passengers[i]->get_seatNumber();
		}
		cout << '\n';
	}

	for (int i = 0; i < capacity; i++)
	{
		if (flights[i]->get_Flight_Identifier() == flightID)
		{
			if (i == 0)
				cout << "\nAll the bookings for the flight " << flightID << " are\n";
			cout << passengers[i]->get_name() << " ";
		}
		cout << '\n';
	}
}