// by Yazan - 40237739 & Parmeet - 40229827
#include "Passenger.h"
#include <string>
using std::string;

//constructors.
Passenger::Passenger(string id = "", string name = "", string address = "", string telephone = "", string seatNumber = "")
{
	this->id = id;
	this->name = name;
	this->address = address;
	this->telephone = telephone;
	this->seatNumber = seatNumber;
}

//setters.
void Passenger::set_id(string id)
{
	this->id = id;
}
void Passenger::set_name(string name)
{
	this->name = name;
}
void Passenger::set_address(string address)
{
	this->address = address;
}
void Passenger::set_telephone(string telephone)
{
	this->telephone = telephone;
}

//getters
string Passenger::get_id() const
{
	return id;
}
string Passenger::get_name() const
{
	return name;
}
string Passenger::get_address() const
{
	return address;
}
string Passenger::get_telephone() const
{
	return telephone;
}

string Passenger::get_seatNumber() const
{
	return seatNumber;
}