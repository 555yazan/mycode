// by Yazan - 40237739 & Parmeet - 40229827
#include "Flight.h"
#include "Time.h"
#include "Date.h"
#include <string>
#include <iostream>
using namespace std;

Flight::Flight(string FI = "", string DC = "", string AC = "", int DoF = 0, Time* AT = 0, Time* DT = 0, Date* DD = 0, Date* AD = 0)
{
    Flight_Identifier = FI;
    d_city = DC;
    a_city = AC;
    duration_of_Flight = DoF;
    a_time = AT;
    d_time = DT;
    d_date = DD;
    a_date = AD;
}

Flight::Flight(const Flight& other)
{
    Flight_Identifier = other.Flight_Identifier;
    d_city = other.d_city;
    a_city = other.a_city;
    duration_of_Flight = other.duration_of_Flight;
    a_time = new Time(other.a_time->get_hours(), other.a_time->get_minutes());
    d_time = new Time(other.d_time->get_hours(), other.d_time->get_minutes());
}

//setters.

void Flight::set_Flight_Identifier(string FI)
{
    Flight_Identifier = FI;
}
void Flight::set_DepartureCity(string DC)
{
    d_city = DC;
}
void Flight::set_Arrival_City(string AC)
{
    a_city = AC;

}
void Flight::set_Duration(int Dur)
{
    duration_of_Flight = Dur;

}

void Flight::set_Arrival_T(Time* AT)
{
    a_time = AT;
}
void Flight::set_Departure_T(Time* DT)
{
    d_time = DT;
}



//getters.

string Flight::get_Flight_Identifier() const
{
    return Flight_Identifier;
}
string Flight::get_DepartureCity() const
{
    return d_city;
}
string Flight::get_Arrival_City() const
{
    return a_city;
}
int Flight::get_Duration() const
{
    return duration_of_Flight;

}

Time* Flight::get_Arrival_Time() const
{
    return a_time;
}

Time* Flight::get_Departure_Time() const
{
    return d_time;
}



//destructor.
Flight::~Flight()
{
    delete a_time;
    delete d_time;
}