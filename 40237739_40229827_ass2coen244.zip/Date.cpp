// by Yazan - 40237739 & Parmeet - 40229827
#include "Date.h"

using namespace std;



Date::Date(int d = 0, int m = 0, int y = 0)
{
    day = d;
    month = m;
    year = y;
}
int Date::getDay() const {

    return day;
}
int Date::getMonth() const{

    return month;
}
int Date::getYear() {

    return year;
}

void Date::setDate(int a, int b, int c)
{
    day = a;
    month = b;
    year = c;
}
void Date::getDate(int a)
{
    if (a == 1)
    {
        cout << "Departure Date : " << day << "/" << month << "/" << year << endl;
    }
    else
    {
        cout << "Arrival Date : " << day << "/" << month << "/" << year << endl;
    }

}


