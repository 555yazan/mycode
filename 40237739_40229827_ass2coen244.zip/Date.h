// by Yazan - 40237739 & Parmeet - 40229827

#ifndef DATE_H
#define DATE_H
#include <iostream>
using namespace std;

class Date
{
    int day;
    int month;
    int year;

public:
    Date(int d, int m, int y);
    int getDay() const;
    int getMonth() const;
    int getYear();
    void setDate(int, int, int);
    void getDate(int);

};
#endif

