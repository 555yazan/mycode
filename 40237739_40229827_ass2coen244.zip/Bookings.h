// by Yazan - 40237739 & Parmeet - 40229827
#ifndef BOOKINGS_H
#define BOOKINGS_H
#include "Flight.h"
#include "Passenger.h"
#include "Time.h"
#include <string>
using namespace std;

class Bookings
{
	Passenger** passengers;
	Flight** flights;
	const int capacity = 10;
	int numPass;
	int numFlights;

public:

	//constructor
	Bookings(int numPass, int numFlights);

	//destructors
	~Bookings();

	//function to make array of objects of class flight and passengers.
	void add_passengers(Passenger* p1);
	void add_flights(Flight* f1);

	//function to list info of passengers
	void Information(string name, string flightID);
};
#endif