// by Yazan - 40237739 & Parmeet - 40229827
#ifndef AIRLINE_H
#define AIRLINE_H
#include "Flight.h"
#include "Time.h"
#include <string>
using namespace std;

class Airline
{
	string telephone;
	string address;
	string name;
	const int capacity = 10;
	Flight** flights;
	int numFlights;

public:
	//constructors
	Airline(string telephone, string address, string name, int numFlights);

	//setters
	void set_telephone(string telephone);
	void set_address(string address);
	void set_name(string name);
	void set_numFlights(int numFlights);

	//getters
	string get_telephone() const;
	string get_address() const;
	string get_name() const;
	int get_numFlights() const;

	~Airline();
	//operations on flight objects
	void addFlights(Flight* flight);
	void removeFlight(string identifier);
	void listDepartingFlights(string DC);
	void listArrivingFlights(string AC);
	void listarrivingandDepartingFlights(string AC, string DC);
	void list_AllFlights();


};

#endif
