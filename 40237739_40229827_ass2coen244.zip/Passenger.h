// by Yazan - 40237739 & Parmeet - 40229827
#ifndef PASSENGER_H
#define PASSENGER_H
#include <string>
using namespace std;

class Passenger
{
	string id;
	string name;
	string address;
	string telephone;
	string seatNumber;
public:

	//constructors.
	Passenger(string id, string name, string address, string telephone, string seatNumber);

	//setters.
	void set_id(string id);
	void set_name(string name);
	void set_address(string address);
	void set_telephone(string telephone);

	//getters
	string get_id() const;
	string get_name() const;
	string get_address() const;
	string get_telephone() const;
	string get_seatNumber() const;
};

#endif
