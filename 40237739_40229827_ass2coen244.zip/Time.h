// by Yazan - 40237739 & Parmeet - 40229827
#ifndef TIME_H
#define TIME_H

class Time
{
	int hour;
	int minutes;
public:
	Time(int h, int min);

	int get_hours() const;
	int get_minutes() const;
};

#endif