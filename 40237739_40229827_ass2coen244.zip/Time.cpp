// by Yazan - 40237739 & Parmeet - 40229827
#include "Time.h"
using namespace std;


Time::Time(int h = 0, int min = 0)
{
	hour = h;
	minutes = min;
}

int Time::get_hours() const
{
	return hour;
}

int Time::get_minutes() const
{
	return minutes;
}