// by Yazan - 40237739 & Parmeet - 40229827
#include"Flight.h"
#include"Flight.cpp"
#include "Time.h"
#include "Time.cpp"
#include "Airline.h"
#include "Airline.cpp"
#include "Passenger.h"
#include "Passenger.cpp"
#include "Bookings.h"
#include "Bookings.cpp"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	cout << "Choose an option:- " << '\n'
		<< "\n1.) Check Q1 of the assignment."
		<< "\n2.) Check Q2 of the assignment."
		<< "\n3.) Check Q3 of the assignment."
		<< "\n4.) Check Q4 of the assignment.\n";
	int opt;
	cin >> opt;

	////test class Flight.
	//Q1.)
	if (opt == 1)
	{
		Time* AT = new Time(8, 10);
		Time* DT = new Time(10, 20);
		Flight flight1("CA150", "Montreal", "Toronto", 5, AT, DT);
		cout << "Flight Identity:- " << flight1.get_Flight_Identifier() << '\n';
		cout << "Departure City is:- " << flight1.get_Arrival_City() << '\n';
		cout << "Arrival City:- " << flight1.get_DepartureCity() << '\n';
		cout << "Duration of Flight:- " << flight1.get_Duration() << '\n\n';
		cout << "Arrival Time:- " << flight1.get_Arrival_Time()->get_hours() << ":" << flight1.get_Arrival_Time()->get_minutes() << '\n';
		cout << "Departure Time:- " << flight1.get_Departure_Time()->get_hours() << ":" << flight1.get_Departure_Time()->get_minutes() << '\n';

		//testing the copy constructor.
		Flight flight2 = flight1;
		cout << "\nFlight Identity:- " << flight2.get_Flight_Identifier() << '\n';
		cout << "Departure City is:- " << flight2.get_Arrival_City() << '\n';
		cout << "Arrival City:- " << flight2.get_DepartureCity() << '\n';
		cout << "Duration of Flight:- " << flight2.get_Duration() << '\n';
		cout << "Arrival Time:- " << flight2.get_Arrival_Time()->get_hours() << ":" << flight2.get_Arrival_Time()->get_minutes() << '\n';
		cout << "Departure Time:- " << flight2.get_Departure_Time()->get_hours() << ":" << flight2.get_Departure_Time()->get_minutes() << '\n';
		delete AT;
		delete DT;
	}

	//Q2.)
	if (opt == 2)
	{
		Time* AT = new Time(8, 10);
		Time* DT = new Time(10, 20);
		Flight* flight1 = new Flight("CA150", "Montreal", "Toronto", 5, AT, DT);
		Flight* flight2 = new Flight("CA10", "Montreal", "Vancouver", 5, AT, DT);
		Flight* flight3 = new Flight("CA50", "Vancouver", "Toronto", 5, AT, DT);

		Airline Coen_Air("123-456-7890", "Montreal", "Coen_Air", 0);

		Coen_Air.addFlights(flight1);
		Coen_Air.addFlights(flight2);
		Coen_Air.addFlights(flight3);

		Coen_Air.listDepartingFlights("Montreal");
		Coen_Air.listArrivingFlights("Toronto");
		Coen_Air.listarrivingandDepartingFlights("Toronto", "Montreal");
		Coen_Air.list_AllFlights();

		delete AT;
		delete DT;
		delete flight1;
	}

	//Q3.)
	//test class passenger.
	if (opt == 3)
	{
		Passenger p1("R123", "Yazan & Parmeet", "LaSalle,Montreal", "+1 514-567-9807", "C32");

		cout << "\nPassenger ID:- " << p1.get_id()
			<< "\nPassenger Name:- " << p1.get_name()
			<< "\nPassenger address:- " << p1.get_address()
			<< "\nPassenger Telephone:- " << p1.get_telephone();
	}

	//Q4.)
	//test class Booking
	if (opt == 4)
	{
		//onbject of class booking
		Bookings B(0, 0);

		//objects of class Flight.
		Time* AT = new Time(8, 10);
		Time* DT = new Time(10, 20);
		Flight* flight1 = new Flight("CA150", "Montreal", "Toronto", 5, AT, DT);
		Flight* flight2 = new Flight("CA10", "Montreal", "Vancouver", 5, AT, DT);
		Flight* flight3 = new Flight("CA50", "Vancouver", "Toronto", 5, AT, DT);

		//object of class Passenger.
		Passenger* p1 = new Passenger("R123", "Yazan & Parmeet", "LaSalle,Montreal", "+1 514-567-9807", "C32");

		//adding objects to the list.
		B.add_flights(flight1);
		B.add_flights(flight2);
		B.add_flights(flight3);

		B.add_passengers(p1);

		//Function to perform operations.
		B.Information("Yazan & Parmeet", "CA150");
	}
	return 0;
}